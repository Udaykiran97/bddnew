package hotelLogin;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(plugin = {"pretty"}, features="D:\\Users\\usayyapu\\Desktop\\newExample\\features\\Booking.feature", glue="{bean)") public class TestRunner {

}